import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { ProblemStatement } from "@/components/problem-statement"
import { Challenges } from "@/components/challenges"
import { Solutions } from "@/components/solutions"
import { Impact } from "@/components/impact"
import { CallToAction } from "@/components/call-to-action"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <ProblemStatement />
        <Challenges />
        <Solutions />
        <Impact />
        <CallToAction />
      </main>
      <Footer />
    </div>
  )
}
