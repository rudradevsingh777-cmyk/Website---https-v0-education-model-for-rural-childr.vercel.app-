import type { Metadata } from "next"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { TeachingMethodsHero } from "@/components/teaching-methods/hero"
import { CorePrinciples } from "@/components/teaching-methods/core-principles"
import { TeachingTechniques } from "@/components/teaching-methods/teaching-techniques"
import { InteractiveKits } from "@/components/teaching-methods/interactive-kits"
import { SubjectActivities } from "@/components/teaching-methods/subject-activities"
import { LowCostMaterials } from "@/components/teaching-methods/low-cost-materials"
import { ClassroomManagement } from "@/components/teaching-methods/classroom-management"
import { AlternativeAssessment } from "@/components/teaching-methods/alternative-assessment"
import { CaseStudies } from "@/components/teaching-methods/case-studies"

export const metadata: Metadata = {
  title: "Alternative Teaching Methods | EduReach",
  description:
    "Comprehensive guide to alternative teaching methods for rural and low-resource schools. Learn activity-based, peer learning, and experiential teaching approaches.",
}

export default function TeachingMethodsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <TeachingMethodsHero />
        <CorePrinciples />
        <TeachingTechniques />
        <InteractiveKits />
        <SubjectActivities />
        <LowCostMaterials />
        <ClassroomManagement />
        <AlternativeAssessment />
        <CaseStudies />
      </main>
      <Footer />
    </div>
  )
}
