"use client"

import type React from "react"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Mail, Phone, MapPin, Send } from "lucide-react"
import { useSearchParams } from "next/navigation"
import { useState, Suspense } from "react"
import { useToast } from "@/hooks/use-toast"

function ContactForm() {
  const searchParams = useSearchParams()
  const type = searchParams.get("type") || "general"
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    type: type,
    message: "",
  })
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    toast({
      title: "Message sent!",
      description: "Thank you for reaching out. We'll get back to you soon.",
    })

    setFormData({ name: "", email: "", phone: "", type: "general", message: "" })
    setIsLoading(false)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="name">Full Name *</Label>
        <Input
          id="name"
          placeholder="Your name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">Email Address *</Label>
        <Input
          id="email"
          type="email"
          placeholder="your.email@example.com"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="phone">Phone Number</Label>
        <Input
          id="phone"
          type="tel"
          placeholder="+1 (555) 000-0000"
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
        />
      </div>

      <div className="space-y-3">
        <Label>I'm interested in *</Label>
        <RadioGroup value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="partner" id="partner" />
            <Label htmlFor="partner" className="font-normal cursor-pointer">
              Partnering with EduReach
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="volunteer" id="volunteer" />
            <Label htmlFor="volunteer" className="font-normal cursor-pointer">
              Volunteering
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="donate" id="donate" />
            <Label htmlFor="donate" className="font-normal cursor-pointer">
              Making a donation
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="general" id="general" />
            <Label htmlFor="general" className="font-normal cursor-pointer">
              General inquiry
            </Label>
          </div>
        </RadioGroup>
      </div>

      <div className="space-y-2">
        <Label htmlFor="message">Message *</Label>
        <Textarea
          id="message"
          placeholder="Tell us more about your interest..."
          rows={6}
          value={formData.message}
          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
          required
        />
      </div>

      <Button type="submit" size="lg" className="w-full gap-2" disabled={isLoading}>
        {isLoading ? "Sending..." : "Send Message"}
        <Send className="h-5 w-5" />
      </Button>
    </form>
  )
}

export default function ContactPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative overflow-hidden border-b bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
          <div className="container px-4 md:px-6 py-24">
            <div className="mx-auto max-w-3xl text-center space-y-6">
              <h1 className="font-poppins font-bold text-4xl md:text-6xl text-balance">Get in Touch</h1>
              <p className="text-lg text-muted-foreground text-pretty leading-relaxed">
                Whether you want to partner, volunteer, donate, or simply learn more, we'd love to hear from you.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-24 md:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid lg:grid-cols-5 gap-12 max-w-6xl mx-auto">
              {/* Contact Form */}
              <Card className="p-8 md:p-12 lg:col-span-3">
                <h2 className="font-poppins font-bold text-2xl md:text-3xl mb-6">Send Us a Message</h2>
                <Suspense fallback={<div>Loading form...</div>}>
                  <ContactForm />
                </Suspense>
              </Card>

              {/* Contact Info */}
              <div className="lg:col-span-2 space-y-8">
                <div>
                  <h3 className="font-poppins font-bold text-2xl mb-6">Contact Information</h3>
                  <div className="space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Mail className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium mb-1">Email</p>
                        <a
                          href="mailto:info@edureach.org"
                          className="text-muted-foreground hover:text-primary transition-colors"
                        >
                          info@edureach.org
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center flex-shrink-0">
                        <Phone className="h-6 w-6 text-secondary" />
                      </div>
                      <div>
                        <p className="font-medium mb-1">Phone</p>
                        <a
                          href="tel:+1234567890"
                          className="text-muted-foreground hover:text-primary transition-colors"
                        >
                          +1 (234) 567-890
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                        <MapPin className="h-6 w-6 text-accent" />
                      </div>
                      <div>
                        <p className="font-medium mb-1">Office</p>
                        <p className="text-muted-foreground leading-relaxed">
                          123 Education Street
                          <br />
                          Learning District
                          <br />
                          City, State 12345
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <Card className="p-6 bg-primary/5 border-primary/20">
                  <h4 className="font-poppins font-semibold text-lg mb-3">Office Hours</h4>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                    <p>Saturday: 10:00 AM - 4:00 PM</p>
                    <p>Sunday: Closed</p>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
