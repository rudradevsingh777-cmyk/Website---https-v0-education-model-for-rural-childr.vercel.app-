import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Target, Eye, Users, Heart, BookOpen, Sparkles } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative overflow-hidden border-b bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
          <div className="container px-4 md:px-6 py-24 md:py-32">
            <div className="mx-auto max-w-3xl text-center space-y-6">
              <div className="inline-flex items-center gap-2 rounded-full border bg-card px-4 py-2 text-sm">
                <Sparkles className="h-4 w-4 text-primary" />
                <span>About EduReach</span>
              </div>
              <h1 className="font-poppins font-bold text-4xl md:text-6xl text-balance">
                Building Bridges to Quality Education
              </h1>
              <p className="text-lg text-muted-foreground text-pretty leading-relaxed">
                We believe that every child, regardless of their geographic or economic circumstances, deserves access
                to meaningful, joyful, and transformative education.
              </p>
            </div>
          </div>
        </section>

        {/* Mission & Vision */}
        <section className="py-24 md:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
              <Card className="p-8 md:p-12">
                <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
                  <Target className="h-8 w-8 text-primary" />
                </div>
                <h2 className="font-poppins font-bold text-3xl mb-4">Our Mission</h2>
                <p className="text-muted-foreground leading-relaxed">
                  To create and implement alternative education models that deliver meaningful, contextual, and holistic
                  learning experiences for children in rural schools facing infrastructural challenges.
                </p>
              </Card>

              <Card className="p-8 md:p-12">
                <div className="w-16 h-16 rounded-xl bg-secondary/10 flex items-center justify-center mb-6">
                  <Eye className="h-8 w-8 text-secondary" />
                </div>
                <h2 className="font-poppins font-bold text-3xl mb-4">Our Vision</h2>
                <p className="text-muted-foreground leading-relaxed">
                  A world where geographical location and economic status are no longer barriers to quality education,
                  and where every child can discover and develop their full potential.
                </p>
              </Card>
            </div>
          </div>
        </section>

        {/* Core Values */}
        <section className="py-24 md:py-32 bg-muted/30">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl text-center mb-16">
              <h2 className="font-poppins font-bold text-3xl md:text-5xl mb-6 text-balance">Our Core Values</h2>
              <p className="text-lg text-muted-foreground text-pretty leading-relaxed">
                These principles guide every decision we make and every program we implement.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <Card className="p-8 text-center hover:shadow-lg transition-shadow">
                <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center mb-4 mx-auto">
                  <Heart className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-poppins font-semibold text-xl mb-3">Child-Centered</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Every child's unique needs, interests, and context are at the heart of our approach.
                </p>
              </Card>

              <Card className="p-8 text-center hover:shadow-lg transition-shadow">
                <div className="w-16 h-16 rounded-xl bg-secondary/10 flex items-center justify-center mb-4 mx-auto">
                  <Users className="h-8 w-8 text-secondary" />
                </div>
                <h3 className="font-poppins font-semibold text-xl mb-3">Community Driven</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  We work with communities, not for them, honoring local knowledge and culture.
                </p>
              </Card>

              <Card className="p-8 text-center hover:shadow-lg transition-shadow">
                <div className="w-16 h-16 rounded-xl bg-accent/10 flex items-center justify-center mb-4 mx-auto">
                  <BookOpen className="h-8 w-8 text-accent" />
                </div>
                <h3 className="font-poppins font-semibold text-xl mb-3">Innovation</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  We continuously explore creative solutions that work within real-world constraints.
                </p>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 md:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl text-center space-y-8">
              <h2 className="font-poppins font-bold text-3xl md:text-5xl text-balance">Ready to Make a Difference?</h2>
              <p className="text-lg text-muted-foreground text-pretty leading-relaxed">
                Join us in transforming rural education and creating opportunities for every child to thrive.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/contact">
                  <Button size="lg">Get Involved</Button>
                </Link>
                <Link href="/">
                  <Button size="lg" variant="outline">
                    Back to Home
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
