"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { BookOpen, Menu } from "lucide-react"
import Link from "next/link"

export function Header() {
  const [isOpen, setIsOpen] = useState(false)

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" })
      setIsOpen(false)
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
            <BookOpen className="h-6 w-6 text-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="font-poppins font-bold text-lg leading-none">EduReach</span>
            <span className="text-xs text-muted-foreground">Alternative Education</span>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          <button
            onClick={() => scrollToSection("problem")}
            className="text-sm font-medium hover:text-primary transition-colors"
          >
            The Problem
          </button>
          <button
            onClick={() => scrollToSection("challenges")}
            className="text-sm font-medium hover:text-primary transition-colors"
          >
            Challenges
          </button>
          <button
            onClick={() => scrollToSection("solutions")}
            className="text-sm font-medium hover:text-primary transition-colors"
          >
            Our Approach
          </button>
          <button
            onClick={() => scrollToSection("impact")}
            className="text-sm font-medium hover:text-primary transition-colors"
          >
            Impact
          </button>
          <Link href="/about">
            <Button variant="ghost" size="sm">
              About
            </Button>
          </Link>
          <Link href="/contact">
            <Button size="sm" className="ml-2">
              Get Involved
            </Button>
          </Link>
          <Link href="/teaching-methods">
            <Button variant="ghost" size="sm">
              Teaching Methods
            </Button>
          </Link>
        </nav>

        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] sm:w-[400px]">
            <nav className="flex flex-col gap-4 mt-8">
              <button
                onClick={() => scrollToSection("problem")}
                className="text-left text-lg font-medium hover:text-primary transition-colors py-2"
              >
                The Problem
              </button>
              <button
                onClick={() => scrollToSection("challenges")}
                className="text-left text-lg font-medium hover:text-primary transition-colors py-2"
              >
                Challenges
              </button>
              <button
                onClick={() => scrollToSection("solutions")}
                className="text-left text-lg font-medium hover:text-primary transition-colors py-2"
              >
                Our Approach
              </button>
              <button
                onClick={() => scrollToSection("impact")}
                className="text-left text-lg font-medium hover:text-primary transition-colors py-2"
              >
                Impact
              </button>
              <Link href="/about" onClick={() => setIsOpen(false)}>
                <Button variant="ghost" className="w-full justify-start text-lg py-2">
                  About
                </Button>
              </Link>
              <Link href="/contact" onClick={() => setIsOpen(false)}>
                <Button className="w-full text-lg py-2 mt-4">Get Involved</Button>
              </Link>
              <Link href="/teaching-methods" onClick={() => setIsOpen(false)}>
                <Button variant="ghost" className="w-full justify-start text-lg py-2">
                  Teaching Methods
                </Button>
              </Link>
            </nav>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}
