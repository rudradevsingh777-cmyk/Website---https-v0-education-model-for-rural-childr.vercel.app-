import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Blocks, Users2, Gamepad2, BookText, MapPin, Handshake, Sprout } from "lucide-react"

const techniques = [
  {
    id: "activity-based",
    label: "Activity-Based",
    icon: Blocks,
    title: "Activity-Based Learning",
    description: "Learning through hands-on activities and practical experiences",
    methods: [
      {
        name: "Learning by Doing",
        details: "Students perform tasks, experiments, and projects to understand concepts",
        examples: ["Building models", "Conducting experiments", "Creating art projects", "Solving puzzles"],
      },
      {
        name: "Discovery Learning",
        details: "Students explore and discover concepts on their own with teacher guidance",
        examples: ["Nature walks", "Observation tasks", "Pattern finding", "Problem investigation"],
      },
      {
        name: "Project-Based Learning",
        details: "Extended projects that integrate multiple subjects and skills",
        examples: ["Community garden", "Village survey", "Water conservation project", "Local history documentation"],
      },
    ],
  },
  {
    id: "peer-learning",
    label: "Peer Learning",
    icon: Users2,
    title: "Peer Learning & Collaboration",
    description: "Students learn from and teach each other",
    methods: [
      {
        name: "Peer Teaching",
        details: "Older or advanced students help younger or struggling students",
        examples: ["Buddy reading", "Math helpers", "Homework support", "Skill demonstrations"],
      },
      {
        name: "Group Work",
        details: "Small groups collaborate on tasks and projects",
        examples: ["Group experiments", "Team presentations", "Collaborative art", "Problem-solving teams"],
      },
      {
        name: "Think-Pair-Share",
        details: "Individual thinking, partner discussion, then class sharing",
        examples: ["Question responses", "Problem solving", "Story analysis", "Concept review"],
      },
    ],
  },
  {
    id: "play-based",
    label: "Play-Based",
    icon: Gamepad2,
    title: "Play-Based Learning",
    description: "Learning through games, role-play, and playful activities",
    methods: [
      {
        name: "Educational Games",
        details: "Games that teach concepts while being fun and engaging",
        examples: ["Number games", "Word building", "Memory games", "Strategy games"],
      },
      {
        name: "Role-Play & Drama",
        details: "Acting out scenarios to understand concepts and develop empathy",
        examples: ["Historical events", "Community helpers", "Story enactment", "Problem scenarios"],
      },
      {
        name: "Simulation Activities",
        details: "Creating real-world scenarios for practical learning",
        examples: ["Market simulation", "Post office play", "Hospital role-play", "Farm activities"],
      },
    ],
  },
  {
    id: "storytelling",
    label: "Storytelling",
    icon: BookText,
    title: "Storytelling & Narrative Learning",
    description: "Using stories to teach concepts and values",
    methods: [
      {
        name: "Story-Based Teaching",
        details: "Embedding lessons within engaging narratives",
        examples: ["Folk tales with morals", "Historical stories", "Science through stories", "Math word problems"],
      },
      {
        name: "Student Storytelling",
        details: "Students create and share their own stories",
        examples: ["Personal experiences", "Creative fiction", "Community stories", "Picture stories"],
      },
      {
        name: "Visual Storytelling",
        details: "Using pictures, drawings, and visual aids to tell stories",
        examples: ["Picture cards", "Story sequences", "Comic strips", "Photo narratives"],
      },
    ],
  },
  {
    id: "learning-stations",
    label: "Learning Stations",
    icon: MapPin,
    title: "Learning Stations & Centers",
    description: "Multiple activity areas for independent and small group work",
    methods: [
      {
        name: "Subject Stations",
        details: "Different corners for different subjects or activities",
        examples: ["Reading corner", "Math station", "Science table", "Art area"],
      },
      {
        name: "Rotation System",
        details: "Students rotate through different stations in groups",
        examples: ["Timed rotations", "Task completion rotations", "Choice-based movement", "Skill-level groups"],
      },
      {
        name: "Independent Work Centers",
        details: "Self-directed learning activities at stations",
        examples: ["Puzzle station", "Writing center", "Building blocks", "Practice worksheets"],
      },
    ],
  },
  {
    id: "community",
    label: "Community",
    icon: Handshake,
    title: "Community Involvement",
    description: "Connecting learning to community and local knowledge",
    methods: [
      {
        name: "Community Experts",
        details: "Inviting local experts to share knowledge and skills",
        examples: [
          "Farmers teaching agriculture",
          "Artisans demonstrating crafts",
          "Elders sharing history",
          "Health workers on hygiene",
        ],
      },
      {
        name: "Field Trips",
        details: "Learning outside the classroom in real-world settings",
        examples: ["Village walks", "Farm visits", "Market trips", "Nature exploration"],
      },
      {
        name: "Service Learning",
        details: "Students contribute to community while learning",
        examples: ["Cleanliness drives", "Tree planting", "Helping elderly", "Teaching younger children"],
      },
    ],
  },
  {
    id: "experiential",
    label: "Experiential",
    icon: Sprout,
    title: "Experiential Learning",
    description: "Learning through direct experience and reflection",
    methods: [
      {
        name: "Observation & Recording",
        details: "Students observe phenomena and document findings",
        examples: ["Weather tracking", "Plant growth", "Animal behavior", "Shadow movement"],
      },
      {
        name: "Experiments & Investigation",
        details: "Hands-on scientific exploration and testing",
        examples: ["Water experiments", "Seed germination", "Simple machines", "Sound and light"],
      },
      {
        name: "Reflection & Discussion",
        details: "Processing experiences through talking and thinking",
        examples: ["What did we learn?", "Why did this happen?", "How can we apply this?", "What surprised us?"],
      },
    ],
  },
]

export function TeachingTechniques() {
  return (
    <section id="teaching-techniques" className="py-16 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4 text-balance">
            Teaching Techniques That Work Without Internet or Electricity
          </h2>
          <p className="text-lg text-muted-foreground text-balance">
            Proven methods that engage students and promote deep learning using minimal resources.
          </p>
        </div>
        <Tabs defaultValue="activity-based" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:grid-cols-7 h-auto gap-2 bg-transparent">
            {techniques.map((technique) => (
              <TabsTrigger
                key={technique.id}
                value={technique.id}
                className="flex flex-col items-center gap-1 py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                <technique.icon className="h-5 w-5" />
                <span className="text-xs">{technique.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>
          {techniques.map((technique) => (
            <TabsContent key={technique.id} value={technique.id} className="mt-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                      <technique.icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-2xl">{technique.title}</CardTitle>
                      <CardDescription className="text-base mt-1">{technique.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {technique.methods.map((method, index) => (
                    <div key={index} className="border-l-4 border-primary/30 pl-4 py-2">
                      <h4 className="font-semibold text-lg mb-2">{method.name}</h4>
                      <p className="text-muted-foreground mb-3 leading-relaxed">{method.details}</p>
                      <div className="flex flex-wrap gap-2">
                        {method.examples.map((example, i) => (
                          <Badge key={i} variant="secondary" className="text-sm">
                            {example}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  )
}
