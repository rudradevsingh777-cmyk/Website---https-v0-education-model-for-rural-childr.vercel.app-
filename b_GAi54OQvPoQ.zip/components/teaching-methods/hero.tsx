"use client"

import { BookOpen, Users, Lightbulb, Heart, Download, Play } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

export function TeachingMethodsHero() {
  const { toast } = useToast()

  const handleDownloadGuide = () => {
    toast({
      title: "Download Started",
      description: "Downloading complete alternative teaching methods guide...",
    })
  }

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-secondary/10 py-20 md:py-28">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            <BookOpen className="h-4 w-4" />
            Comprehensive Teaching Guide
          </div>
          <h1 className="mb-6 text-4xl font-bold tracking-tight text-balance sm:text-5xl md:text-6xl">
            Alternative Teaching Methods for Rural Schools
          </h1>
          <p className="mb-8 text-lg text-muted-foreground text-balance md:text-xl leading-relaxed">
            A complete guide to implementing meaningful, engaging, and effective teaching strategies that work without
            internet, electricity, or expensive resources.
          </p>
          <div className="flex flex-wrap gap-4 justify-center mb-12">
            <Button size="lg" onClick={handleDownloadGuide}>
              <Download className="h-5 w-5 mr-2" />
              Download Complete Guide
            </Button>
            <Dialog>
              <DialogTrigger asChild>
                <Button size="lg" variant="outline">
                  <Play className="h-5 w-5 mr-2" />
                  Watch Introduction
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-3xl">
                <DialogHeader>
                  <DialogTitle>Introduction to Alternative Teaching Methods</DialogTitle>
                  <DialogDescription>Learn how these methods can transform learning in rural schools</DialogDescription>
                </DialogHeader>
                <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <Play className="h-16 w-16 mx-auto mb-4 text-primary" />
                    <p className="text-muted-foreground">Video introduction coming soon</p>
                  </div>
                </div>
                <div className="space-y-2 text-sm">
                  <p>This video will cover:</p>
                  <ul className="space-y-1 ml-4">
                    <li>• Why alternative methods work better for rural contexts</li>
                    <li>• Overview of key teaching techniques</li>
                    <li>• Real examples from successful implementations</li>
                    <li>• How to get started in your classroom</li>
                  </ul>
                </div>
              </DialogContent>
            </Dialog>
            <Button size="lg" variant="secondary" onClick={() => scrollToSection("core-principles")}>
              Get Started
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4 mt-12">
            <div className="flex flex-col items-center gap-2">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <BookOpen className="h-6 w-6 text-primary" />
              </div>
              <span className="text-sm font-medium">Activity-Based</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-secondary/10">
                <Users className="h-6 w-6 text-secondary" />
              </div>
              <span className="text-sm font-medium">Peer Learning</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/10">
                <Lightbulb className="h-6 w-6 text-accent" />
              </div>
              <span className="text-sm font-medium">Experiential</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Heart className="h-6 w-6 text-primary" />
              </div>
              <span className="text-sm font-medium">Community-Led</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
