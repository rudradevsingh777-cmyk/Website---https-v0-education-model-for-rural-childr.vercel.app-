"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Users, TrendingUp, Quote } from "lucide-react"
import { Button } from "@/components/ui/button"
import { FileText, Share2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

const caseStudies = [
  {
    location: "Rajasthan, India",
    school: "Government Primary School, Khejroli Village",
    context: "Single-teacher school with 45 students across grades 1-5, no electricity, limited materials",
    intervention: "Implemented learning stations, peer teaching, and locally-made learning kits",
    outcomes: [
      "Reading levels improved by 2 grades in 6 months",
      "Math problem-solving skills increased significantly",
      "Student attendance improved from 60% to 85%",
      "Community engagement increased with parents volunteering",
    ],
    quote: "The children are so excited to come to school now. They're learning by doing, not just listening.",
    teacher: "Meera Sharma, Teacher",
  },
  {
    location: "Bihar, India",
    school: "Cluster of 3 Rural Schools",
    context: "Multi-grade classrooms, high dropout rates, traditional rote learning methods",
    intervention: "Introduced activity-based learning, storytelling, and community involvement",
    outcomes: [
      "Dropout rate reduced from 30% to 8%",
      "Students able to apply learning to real-life situations",
      "Increased confidence and participation in class",
      "Teachers reported more job satisfaction",
    ],
    quote: "Students who couldn't read are now reading stories to their younger siblings. The change is remarkable.",
    teacher: "Rajesh Kumar, Cluster Coordinator",
  },
  {
    location: "Madhya Pradesh, India",
    school: "Tribal Area Primary School",
    context: "Remote location, first-generation learners, language barriers, minimal resources",
    intervention: "Used local materials, incorporated tribal knowledge, play-based learning",
    outcomes: [
      "Students connected school learning to their lives",
      "Improved understanding of concepts through hands-on activities",
      "Parents began valuing education more",
      "Cultural pride increased alongside academic learning",
    ],
    quote: "When we started using examples from their daily lives and nature around them, everything changed.",
    teacher: "Sunita Patel, Head Teacher",
  },
  {
    location: "Uttar Pradesh, India",
    school: "Government Girls' School",
    context: "Low enrollment, girls dropping out after grade 3, traditional teaching methods",
    intervention: "Implemented peer learning, life skills education, and project-based learning",
    outcomes: [
      "Girls' enrollment increased by 40%",
      "Retention through grade 5 improved to 90%",
      "Students developed leadership and communication skills",
      "Community attitudes toward girls' education shifted positively",
    ],
    quote: "The girls are not just learning subjects, they're learning to think, question, and lead.",
    teacher: "Anjali Verma, Teacher",
  },
]

const keyLearnings = [
  {
    title: "Teacher Training is Essential",
    description:
      "Teachers need support and training to shift from traditional to alternative methods. Regular workshops and peer learning help.",
  },
  {
    title: "Start Small and Build",
    description:
      "Begin with one or two methods, master them, then gradually add more. Don't try to change everything at once.",
  },
  {
    title: "Community Support Matters",
    description: "When parents and community understand and support the approach, success is much more likely.",
  },
  {
    title: "Context is Key",
    description:
      "Adapt methods to local context, culture, and resources. What works in one place may need modification elsewhere.",
  },
  {
    title: "Student Voice is Powerful",
    description:
      "When students are involved in their learning and have choices, engagement and outcomes improve dramatically.",
  },
  {
    title: "Patience and Persistence",
    description:
      "Change takes time. Initial challenges are normal. Consistent implementation leads to lasting results.",
  },
]

export function CaseStudies() {
  const { toast } = useToast()

  const handleShare = (schoolName: string) => {
    toast({
      title: "Case Study Shared",
      description: `${schoolName} success story copied to clipboard`,
    })
  }

  const handleDownloadCase = (schoolName: string) => {
    toast({
      title: "Download Started",
      description: `Downloading detailed case study for ${schoolName}...`,
    })
  }

  return (
    <section id="case-studies" className="py-16 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4 text-balance">
            Real-Life Examples & Case Studies
          </h2>
          <p className="text-lg text-muted-foreground text-balance">
            Success stories from rural schools that have transformed learning through alternative teaching methods.
          </p>
        </div>

        <div className="space-y-6 mb-12">
          {caseStudies.map((study, index) => (
            <Card key={index} className="border-2">
              <CardHeader>
                <div className="flex items-start justify-between gap-4 mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="h-4 w-4 text-primary" />
                      <Badge variant="secondary">{study.location}</Badge>
                    </div>
                    <CardTitle className="text-xl mb-1">{study.school}</CardTitle>
                    <CardDescription className="text-base">{study.context}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <Users className="h-4 w-4 text-primary" />
                    Intervention
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">{study.intervention}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-primary" />
                    Outcomes
                  </h4>
                  <ul className="space-y-1.5">
                    {study.outcomes.map((outcome, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <span className="text-green-600 mt-0.5">✓</span>
                        <span className="leading-relaxed">{outcome}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="pt-3 border-t bg-muted/30 -mx-6 px-6 py-4">
                  <div className="flex gap-3">
                    <Quote className="h-5 w-5 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <p className="text-sm italic leading-relaxed mb-2">{study.quote}</p>
                      <p className="text-xs font-semibold text-muted-foreground">— {study.teacher}</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleDownloadCase(study.school)}>
                    <FileText className="h-4 w-4 mr-1" />
                    Full Report
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleShare(study.school)}>
                    <Share2 className="h-4 w-4 mr-1" />
                    Share
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16">
          <h3 className="text-2xl font-bold text-center mb-8">Key Learnings from Success Stories</h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {keyLearnings.map((learning, index) => (
              <Card key={index} className="border-2 bg-primary/5">
                <CardHeader>
                  <CardTitle className="text-lg">{learning.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm leading-relaxed text-muted-foreground">{learning.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <Card className="mt-12 border-2 border-primary bg-gradient-to-br from-primary/10 to-secondary/10">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Expected Outcomes of Alternative Teaching</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h4 className="font-semibold mb-3 text-primary">For Students:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Deeper understanding of concepts, not just memorization</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Increased engagement, curiosity, and love for learning</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Development of critical thinking and problem-solving skills</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Improved confidence and communication abilities</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Better retention and ability to apply learning</span>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-3 text-primary">For Schools & Communities:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Improved attendance and reduced dropout rates</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>More positive school environment and culture</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Increased community involvement and support</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Teachers feel more effective and satisfied</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Better learning outcomes with same or fewer resources</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
