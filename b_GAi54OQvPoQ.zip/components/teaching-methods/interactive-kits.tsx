"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, Blocks, FlaskConical, Drama, Calculator, Leaf, Puzzle, Hammer, Download, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

const kits = [
  {
    icon: FileText,
    title: "Print-Based Learning Cards",
    description: "Durable cards with images, words, numbers, and concepts",
    contents: [
      "Alphabet cards with pictures",
      "Number cards (1-100)",
      "Sight word cards",
      "Picture vocabulary cards",
      "Concept cards (colors, shapes, animals)",
      "Story sequence cards",
    ],
    subjects: ["Language", "Math", "EVS"],
    cost: "Very Low",
  },
  {
    icon: Blocks,
    title: "Manipulatives Kit",
    description: "Physical objects for hands-on learning and counting",
    contents: [
      "Counting stones/seeds",
      "Pattern blocks",
      "Fraction circles",
      "Place value cards",
      "Geometric shapes",
      "Sorting objects",
    ],
    subjects: ["Math", "Science"],
    cost: "Low",
  },
  {
    icon: FlaskConical,
    title: "Experiment Kit",
    description: "Simple materials for conducting basic science experiments",
    contents: [
      "Magnifying glass",
      "Measuring cups",
      "Seeds for planting",
      "pH paper",
      "Thermometer",
      "Collection jars",
    ],
    subjects: ["Science", "EVS"],
    cost: "Low",
  },
  {
    icon: Drama,
    title: "Role-Play Kit",
    description: "Props and costumes for dramatic play and storytelling",
    contents: [
      "Simple costumes",
      "Puppets (handmade)",
      "Props for community helpers",
      "Story masks",
      "Character cards",
      "Scene backgrounds",
    ],
    subjects: ["Language", "Life Skills", "EVS"],
    cost: "Very Low",
  },
  {
    icon: Calculator,
    title: "Math Kit",
    description: "Tools for teaching mathematical concepts concretely",
    contents: [
      "Abacus or counting frame",
      "Number line",
      "Fraction strips",
      "Measurement tools",
      "Dice and spinners",
      "Math games",
    ],
    subjects: ["Math"],
    cost: "Low",
  },
  {
    icon: Leaf,
    title: "Local-Material Science Kit",
    description: "Science learning using locally available natural materials",
    contents: [
      "Leaf collection",
      "Rock samples",
      "Soil types",
      "Water samples",
      "Plant parts",
      "Insect observation box",
    ],
    subjects: ["Science", "EVS"],
    cost: "Free",
  },
  {
    icon: Puzzle,
    title: "Learning Puzzles",
    description: "Educational puzzles for problem-solving and concept reinforcement",
    contents: [
      "Map puzzles",
      "Number puzzles",
      "Word building puzzles",
      "Pattern completion",
      "Matching games",
      "Sequence puzzles",
    ],
    subjects: ["All Subjects"],
    cost: "Low",
  },
  {
    icon: Hammer,
    title: "Skill-Building Project Kit",
    description: "Materials for hands-on projects and practical skills",
    contents: [
      "Building materials",
      "Art supplies",
      "Craft materials",
      "Gardening tools",
      "Sewing supplies",
      "Woodworking basics",
    ],
    subjects: ["Life Skills", "Art"],
    cost: "Low",
  },
]

export function InteractiveKits() {
  const { toast } = useToast()

  const handleDownload = (kitTitle: string) => {
    toast({
      title: "Download Started",
      description: `Downloading ${kitTitle} guide and template...`,
    })
  }

  return (
    <section id="interactive-kits" className="py-16 md:py-24 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4 text-balance">Student Interactive Kits</h2>
          <p className="text-lg text-muted-foreground text-balance">
            Offline learning tools that make abstract concepts concrete and learning engaging for all subjects.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {kits.map((kit, index) => (
            <Card key={index} className="border-2 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                  <kit.icon className="h-7 w-7 text-primary" />
                </div>
                <CardTitle className="text-xl">{kit.title}</CardTitle>
                <CardDescription className="text-base">{kit.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-sm mb-2 text-muted-foreground">Contents:</h4>
                  <ul className="space-y-1 text-sm">
                    {kit.contents.map((item, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-primary mt-1">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="flex items-center justify-between pt-2 border-t">
                  <div className="text-sm">
                    <span className="font-semibold">Subjects: </span>
                    <span className="text-muted-foreground">{kit.subjects.join(", ")}</span>
                  </div>
                  <div
                    className={`text-xs font-semibold px-2 py-1 rounded ${
                      kit.cost === "Free"
                        ? "bg-green-100 text-green-700"
                        : kit.cost === "Very Low"
                          ? "bg-blue-100 text-blue-700"
                          : "bg-yellow-100 text-yellow-700"
                    }`}
                  >
                    {kit.cost}
                  </div>
                </div>
                <div className="flex gap-2 pt-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                        <Info className="h-4 w-4 mr-1" />
                        Details
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-3">
                          <kit.icon className="h-6 w-6 text-primary" />
                          {kit.title}
                        </DialogTitle>
                        <DialogDescription>{kit.description}</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 mt-4">
                        <div>
                          <h4 className="font-semibold mb-2">Complete Contents:</h4>
                          <ul className="space-y-2">
                            {kit.contents.map((item, i) => (
                              <li key={i} className="flex items-start gap-2 text-sm">
                                <span className="text-primary mt-1">✓</span>
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">How to Create:</h4>
                          <p className="text-sm text-muted-foreground leading-relaxed">
                            This kit can be assembled using locally available materials. Involve students in creating
                            and organizing the kit - it becomes a learning activity itself. Store items in labeled boxes
                            or bags for easy access.
                          </p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">Usage Tips:</h4>
                          <ul className="space-y-1 text-sm text-muted-foreground">
                            <li>• Introduce one item at a time to avoid overwhelming students</li>
                            <li>• Demonstrate proper handling and storage</li>
                            <li>• Encourage exploration and creativity</li>
                            <li>• Rotate items regularly to maintain interest</li>
                          </ul>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                  <Button size="sm" className="flex-1" onClick={() => handleDownload(kit.title)}>
                    <Download className="h-4 w-4 mr-1" />
                    Guide
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
