"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Clock, Target, BookOpen, Star, Heart, Download, Lightbulb } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

const strategies = [
  {
    icon: Users,
    title: "Multi-Grade Grouping",
    description: "Effective strategies for teaching multiple grades simultaneously",
    techniques: [
      "Peer tutoring: Older students help younger ones",
      "Flexible grouping: Group by skill level, not just age",
      "Learning stations: Different activities for different levels",
      "Common themes: Same topic, different complexity levels",
      "Independent work: Self-directed activities for some while teaching others",
    ],
  },
  {
    icon: Clock,
    title: "Time Management",
    description: "Making the most of limited instructional time",
    techniques: [
      "Structured daily routine: Predictable schedule helps students",
      "Transition signals: Songs, claps, or bells to move between activities",
      "Time blocks: Dedicate specific times to subjects",
      "Integrated learning: Combine subjects when possible",
      "Maximize learning time: Minimize waiting and idle time",
    ],
  },
  {
    icon: Target,
    title: "Differentiated Instruction",
    description: "Meeting diverse learning needs in one classroom",
    techniques: [
      "Tiered activities: Same concept, different difficulty levels",
      "Choice boards: Students choose from activity options",
      "Flexible pacing: Allow students to progress at their own speed",
      "Multiple entry points: Different ways to access the same content",
      "Varied assessment: Different ways to show understanding",
    ],
  },
  {
    icon: BookOpen,
    title: "Resource Management",
    description: "Organizing and maximizing limited materials",
    techniques: [
      "Material rotation: Share resources between groups",
      "Student helpers: Assign roles for distributing materials",
      "Organized storage: Clear labeling and designated spaces",
      "Care routines: Teach students to maintain materials",
      "Community library: Shared resources across classrooms",
    ],
  },
  {
    icon: Star,
    title: "Positive Behavior Support",
    description: "Creating a supportive and respectful learning environment",
    techniques: [
      "Clear expectations: Simple, positive rules co-created with students",
      "Recognition system: Acknowledge positive behavior and effort",
      "Restorative practices: Focus on learning from mistakes",
      "Class meetings: Regular discussions about classroom community",
      "Responsibility roles: Give students meaningful classroom jobs",
    ],
  },
  {
    icon: Heart,
    title: "Inclusive Practices",
    description: "Ensuring all students feel valued and can participate",
    techniques: [
      "Universal design: Activities accessible to all abilities",
      "Buddy system: Pair students for support",
      "Multiple modalities: Visual, auditory, kinesthetic options",
      "Cultural responsiveness: Honor all backgrounds and languages",
      "Emotional support: Create safe space for all learners",
    ],
  },
]

export function ClassroomManagement() {
  const { toast } = useToast()

  const handleDownloadStrategy = (strategyTitle: string) => {
    toast({
      title: "Download Started",
      description: `Downloading detailed guide for "${strategyTitle}"...`,
    })
  }

  return (
    <section id="classroom-management" className="py-16 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4 text-balance">
            Classroom Management for Multi-Grade Settings
          </h2>
          <p className="text-lg text-muted-foreground text-balance">
            Practical strategies for managing diverse classrooms with limited resources and multiple grade levels.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {strategies.map((strategy, index) => (
            <Card key={index} className="border-2 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <strategy.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-xl">{strategy.title}</CardTitle>
                <CardDescription className="text-base">{strategy.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {strategy.techniques.map((technique, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm">
                      <span className="text-primary mt-1 font-bold">•</span>
                      <span className="leading-relaxed">{technique}</span>
                    </li>
                  ))}
                </ul>
                <div className="flex gap-2 pt-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                        <Lightbulb className="h-4 w-4 mr-1" />
                        Examples
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                          <strategy.icon className="h-5 w-5 text-primary" />
                          {strategy.title} - Practical Examples
                        </DialogTitle>
                        <DialogDescription>{strategy.description}</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 mt-4">
                        <div>
                          <h4 className="font-semibold mb-2">Real Classroom Scenario:</h4>
                          <p className="text-sm text-muted-foreground leading-relaxed">
                            A teacher manages 40 students across grades 1-5 in a single classroom. By implementing these
                            strategies, students work independently at learning stations while the teacher provides
                            targeted instruction to small groups.
                          </p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">Implementation Tips:</h4>
                          <ul className="space-y-2 text-sm text-muted-foreground">
                            <li>• Start with one technique and master it before adding more</li>
                            <li>• Involve students in creating systems and routines</li>
                            <li>• Be consistent and patient - new systems take time</li>
                            <li>• Adapt strategies to your specific context and resources</li>
                          </ul>
                        </div>
                      </div>
                      <Button className="w-full mt-4" onClick={() => handleDownloadStrategy(strategy.title)}>
                        <Download className="h-4 w-4 mr-2" />
                        Download Complete Guide
                      </Button>
                    </DialogContent>
                  </Dialog>
                  <Button size="sm" className="flex-1" onClick={() => handleDownloadStrategy(strategy.title)}>
                    <Download className="h-4 w-4 mr-1" />
                    Guide
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
