"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Leaf, Recycle, Coins, Scissors } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Download, Lightbulb } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

const categories = [
  {
    icon: Leaf,
    title: "Natural Materials (Free)",
    color: "bg-green-100 text-green-700",
    items: [
      { name: "Stones & Pebbles", uses: "Counting, patterns, art, weighing" },
      { name: "Leaves & Flowers", uses: "Classification, art, science observation" },
      { name: "Sticks & Twigs", uses: "Counting, building, measurement" },
      { name: "Seeds", uses: "Counting, planting, patterns, sorting" },
      { name: "Soil & Sand", uses: "Science experiments, sensory learning" },
      { name: "Water", uses: "Experiments, measurement, cleaning" },
    ],
  },
  {
    icon: Recycle,
    title: "Recycled Materials (Free)",
    color: "bg-blue-100 text-blue-700",
    items: [
      { name: "Cardboard Boxes", uses: "Building, storage, learning stations" },
      { name: "Plastic Bottles", uses: "Experiments, planters, storage" },
      { name: "Newspaper", uses: "Papier-mâché, wrapping, reading practice" },
      { name: "Bottle Caps", uses: "Counting, patterns, games" },
      { name: "Fabric Scraps", uses: "Sewing, puppets, costumes" },
      { name: "Egg Cartons", uses: "Sorting, counting, planting" },
    ],
  },
  {
    icon: Coins,
    title: "Low-Cost Purchases",
    color: "bg-yellow-100 text-yellow-700",
    items: [
      { name: "Chalk", uses: "Writing, drawing, number lines" },
      { name: "String/Rope", uses: "Measurement, patterns, games" },
      { name: "Paper", uses: "Writing, drawing, folding activities" },
      { name: "Crayons/Pencils", uses: "Drawing, writing, coloring" },
      { name: "Glue", uses: "Crafts, projects, repairs" },
      { name: "Dice", uses: "Math games, probability, counting" },
    ],
  },
  {
    icon: Scissors,
    title: "DIY Learning Resources",
    color: "bg-purple-100 text-purple-700",
    items: [
      { name: "Handmade Flashcards", uses: "Vocabulary, numbers, concepts" },
      { name: "Cloth Puppets", uses: "Storytelling, role-play, drama" },
      { name: "Paper Games", uses: "Learning games, puzzles, activities" },
      { name: "Painted Stones", uses: "Counting, letters, matching games" },
      { name: "Cardboard Puzzles", uses: "Problem-solving, fine motor skills" },
      { name: "Bottle Cap Counters", uses: "Math operations, patterns" },
    ],
  },
]

export function LowCostMaterials() {
  const { toast } = useToast()

  const handleDownload = (materialType: string) => {
    toast({
      title: "Download Started",
      description: `Downloading ${materialType} guide with detailed instructions...`,
    })
  }

  return (
    <section id="low-cost-materials" className="py-16 md:py-24 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4 text-balance">
            Low-Cost Materials & DIY Resources
          </h2>
          <p className="text-lg text-muted-foreground text-balance">
            Transform everyday and natural materials into powerful learning tools without spending much.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {categories.map((category, index) => (
            <Card key={index} className="border-2">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${category.color}`}>
                    <category.icon className="h-6 w-6" />
                  </div>
                  <CardTitle className="text-xl">{category.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {category.items.map((item, i) => (
                    <div key={i} className="border-l-2 border-primary/30 pl-3 py-1">
                      <h4 className="font-semibold text-sm">{item.name}</h4>
                      <p className="text-sm text-muted-foreground">{item.uses}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-4">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="w-full bg-transparent">
                        <Lightbulb className="h-4 w-4 mr-2" />
                        Activity Ideas
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                          <category.icon className="h-5 w-5 text-primary" />
                          {category.title} - Activity Ideas
                        </DialogTitle>
                        <DialogDescription>Creative ways to use these materials in your classroom</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-3 mt-4">
                        {category.items.slice(0, 3).map((item, i) => (
                          <div key={i} className="border-l-4 border-primary/30 pl-3 py-2">
                            <h4 className="font-semibold text-sm mb-1">{item.name} Activities:</h4>
                            <ul className="space-y-1 text-sm text-muted-foreground">
                              <li>• Create hands-on learning stations</li>
                              <li>• Design interactive group activities</li>
                              <li>• Use for assessment and demonstration</li>
                              <li>• Incorporate into storytelling sessions</li>
                            </ul>
                          </div>
                        ))}
                      </div>
                      <Button className="w-full mt-4" onClick={() => handleDownload(category.title)}>
                        <Download className="h-4 w-4 mr-2" />
                        Download Complete Activity Guide
                      </Button>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <Card className="mt-8 border-2 border-primary/20 bg-primary/5">
          <CardHeader>
            <CardTitle className="text-xl">Tips for Creating DIY Materials</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm leading-relaxed">
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold mt-1">•</span>
                <span>
                  <strong>Durability:</strong> Laminate paper materials or cover with clear tape for longer life
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold mt-1">•</span>
                <span>
                  <strong>Storage:</strong> Use boxes, bags, or containers to organize materials by subject or activity
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold mt-1">•</span>
                <span>
                  <strong>Student Involvement:</strong> Have students help create materials - it's a learning activity
                  itself
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold mt-1">•</span>
                <span>
                  <strong>Community Resources:</strong> Ask parents and community members to donate or help create
                  materials
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold mt-1">•</span>
                <span>
                  <strong>Reusability:</strong> Design materials that can be used for multiple purposes and grade levels
                </span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
