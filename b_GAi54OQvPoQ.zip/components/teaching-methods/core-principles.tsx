"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Target, Users, Sparkles, Heart, Brain, Leaf } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Info } from "lucide-react"

const principles = [
  {
    icon: Target,
    title: "Child-Centered Learning",
    description:
      "Focus on the child's interests, pace, and learning style. Every child is unique and learns differently.",
    color: "text-primary",
  },
  {
    icon: Users,
    title: "Collaborative & Social",
    description:
      "Learning happens best in community. Encourage peer teaching, group work, and collaborative problem-solving.",
    color: "text-secondary",
  },
  {
    icon: Sparkles,
    title: "Hands-On & Experiential",
    description:
      "Learning by doing is more effective than passive listening. Use real objects, experiments, and activities.",
    color: "text-accent",
  },
  {
    icon: Heart,
    title: "Culturally Relevant",
    description:
      "Connect learning to local context, traditions, and community knowledge. Use familiar examples and stories.",
    color: "text-primary",
  },
  {
    icon: Brain,
    title: "Multi-Sensory Engagement",
    description: "Engage all senses - visual, auditory, kinesthetic, and tactile - to reinforce learning and memory.",
    color: "text-secondary",
  },
  {
    icon: Leaf,
    title: "Nature & Environment",
    description:
      "Use the natural environment as a classroom. Outdoor learning is free, engaging, and deeply educational.",
    color: "text-accent",
  },
]

export function CorePrinciples() {
  return (
    <section id="core-principles" className="py-16 md:py-24 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4 text-balance">
            Core Principles of Alternative Pedagogy
          </h2>
          <p className="text-lg text-muted-foreground text-balance">
            These foundational principles guide all alternative teaching methods and ensure meaningful learning
            experiences.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {principles.map((principle, index) => (
            <Card key={index} className="border-2 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className={`mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10`}>
                  <principle.icon className={`h-6 w-6 ${principle.color}`} />
                </div>
                <CardTitle className="text-xl">{principle.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <CardDescription className="text-base leading-relaxed">{principle.description}</CardDescription>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="w-full bg-transparent">
                      <Info className="h-4 w-4 mr-2" />
                      Learn More
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <principle.icon className={`h-5 w-5 ${principle.color}`} />
                        {principle.title}
                      </DialogTitle>
                      <DialogDescription>{principle.description}</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-3 mt-4">
                      <div>
                        <h4 className="font-semibold text-sm mb-2">How to Apply:</h4>
                        <ul className="space-y-2 text-sm text-muted-foreground">
                          <li>• Observe students to understand their interests and learning styles</li>
                          <li>• Create activities that allow for different approaches</li>
                          <li>• Provide choices whenever possible</li>
                          <li>• Connect lessons to students' lived experiences</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-semibold text-sm mb-2">Example Activity:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Students explore a topic through their preferred method - some might draw, others write, some
                          act it out, and others build models. All paths lead to the same learning goal.
                        </p>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
