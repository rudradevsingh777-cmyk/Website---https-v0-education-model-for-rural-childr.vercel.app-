"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FolderOpen, Eye, MessageSquare, CheckSquare, TrendingUp, Users, Download, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

const methods = [
  {
    icon: FolderOpen,
    title: "Portfolio Assessment",
    description: "Collection of student work over time showing growth and learning",
    implementation: [
      "Collect samples of student work regularly (weekly or monthly)",
      "Include different types of work: writing, drawings, projects, photos",
      "Have students select pieces that show their best work or growth",
      "Review portfolios with students to discuss progress",
      "Share portfolios with parents during meetings",
    ],
    benefits: "Shows progress over time, celebrates growth, involves students in assessment",
  },
  {
    icon: Eye,
    title: "Observation Sheets",
    description: "Systematic recording of student behaviors, skills, and understanding",
    implementation: [
      "Create simple checklists for key skills in each subject",
      "Observe students during activities and mark progress",
      "Note specific examples of understanding or challenges",
      "Focus on a few students each day for detailed observation",
      "Use observations to plan next steps in teaching",
    ],
    benefits: "Captures real learning in action, identifies needs, guides instruction",
  },
  {
    icon: MessageSquare,
    title: "Oral Assessment",
    description: "Conversations and discussions to understand student thinking",
    implementation: [
      "Ask open-ended questions during activities",
      "Have students explain their thinking and reasoning",
      "Conduct one-on-one or small group discussions",
      "Listen for understanding, not just correct answers",
      "Record key insights about student comprehension",
    ],
    benefits: "Reveals thinking process, builds communication skills, immediate feedback",
  },
  {
    icon: CheckSquare,
    title: "Performance Tasks",
    description: "Students demonstrate learning through practical application",
    implementation: [
      "Design tasks that require applying knowledge and skills",
      "Examples: Solve a real problem, create something, teach others",
      "Observe students during the task",
      "Use simple rubrics to assess different aspects",
      "Provide feedback on process and product",
    ],
    benefits: "Assesses real-world application, engaging for students, shows multiple skills",
  },
  {
    icon: TrendingUp,
    title: "Progress Tracking",
    description: "Visual records of skill development and goal achievement",
    implementation: [
      "Create simple charts for key skills (reading levels, math facts, etc.)",
      "Update regularly with student involvement",
      "Use colors, stickers, or marks to show progress",
      "Celebrate milestones and improvements",
      "Set new goals based on progress",
    ],
    benefits: "Motivates students, makes learning visible, tracks growth over time",
  },
  {
    icon: Users,
    title: "Peer & Self-Assessment",
    description: "Students evaluate their own and others' work",
    implementation: [
      "Teach students to give constructive feedback",
      "Use simple criteria or checklists",
      "Have students assess their own work first",
      "Pair students to review each other's work",
      "Discuss what makes good work in each subject",
    ],
    benefits: "Develops critical thinking, increases ownership, builds assessment literacy",
  },
]

export function AlternativeAssessment() {
  const { toast } = useToast()

  const handleDownloadTemplate = (methodTitle: string) => {
    toast({
      title: "Download Started",
      description: `Downloading ${methodTitle} template and guide...`,
    })
  }

  return (
    <section id="alternative-assessment" className="py-16 md:py-24 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4 text-balance">Assessment Without Exams</h2>
          <p className="text-lg text-muted-foreground text-balance">
            Meaningful ways to understand and document student learning without traditional testing.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {methods.map((method, index) => (
            <Card key={index} className="border-2">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <method.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">{method.title}</CardTitle>
                    <CardDescription className="text-sm mt-1">{method.description}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-sm mb-2 text-primary">How to Implement:</h4>
                  <ul className="space-y-1.5">
                    {method.implementation.map((step, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <span className="text-primary mt-0.5">•</span>
                        <span className="leading-relaxed">{step}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="pt-3 border-t">
                  <p className="text-sm">
                    <span className="font-semibold text-primary">Benefits: </span>
                    <span className="text-muted-foreground">{method.benefits}</span>
                  </p>
                </div>
                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                        <FileText className="h-4 w-4 mr-1" />
                        Sample
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                          <method.icon className="h-5 w-5 text-primary" />
                          {method.title} - Sample & Template
                        </DialogTitle>
                        <DialogDescription>Example of how to use this assessment method</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 mt-4">
                        <div className="border-2 border-primary/20 rounded-lg p-4 bg-muted/30">
                          <h4 className="font-semibold mb-2">Example Format:</h4>
                          <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                            This template provides a structured way to implement {method.title.toLowerCase()} in your
                            classroom. Customize it based on your specific needs and context.
                          </p>
                          <div className="bg-background p-3 rounded border text-xs font-mono">
                            <div>Student Name: __________________</div>
                            <div>Date: __________________</div>
                            <div>Subject/Topic: __________________</div>
                            <div className="mt-2">Assessment Criteria:</div>
                            <div className="ml-2">□ Demonstrates understanding</div>
                            <div className="ml-2">□ Can apply knowledge</div>
                            <div className="ml-2">□ Shows improvement</div>
                            <div className="mt-2">Notes: ____________________</div>
                          </div>
                        </div>
                        <Button className="w-full" onClick={() => handleDownloadTemplate(method.title)}>
                          <Download className="h-4 w-4 mr-2" />
                          Download Editable Template
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                  <Button size="sm" className="flex-1" onClick={() => handleDownloadTemplate(method.title)}>
                    <Download className="h-4 w-4 mr-1" />
                    Template
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <Card className="mt-8 border-2 border-primary/20 bg-primary/5">
          <CardHeader>
            <CardTitle className="text-xl">Why Alternative Assessment?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <h4 className="font-semibold mb-2 text-primary">Traditional Exams Often:</h4>
                <ul className="space-y-1 text-sm">
                  <li className="flex items-start gap-2">
                    <span className="text-destructive mt-1">✗</span>
                    <span>Cause anxiety and stress</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-destructive mt-1">✗</span>
                    <span>Test memorization, not understanding</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-destructive mt-1">✗</span>
                    <span>Provide limited feedback</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-destructive mt-1">✗</span>
                    <span>Don't show real-world application</span>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2 text-primary">Alternative Assessment:</h4>
                <ul className="space-y-1 text-sm">
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">✓</span>
                    <span>Reduces stress, increases engagement</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">✓</span>
                    <span>Assesses deep understanding</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">✓</span>
                    <span>Provides ongoing, actionable feedback</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">✓</span>
                    <span>Shows practical skills and application</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
