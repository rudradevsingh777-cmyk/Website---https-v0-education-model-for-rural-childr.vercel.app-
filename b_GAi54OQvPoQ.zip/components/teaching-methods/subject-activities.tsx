"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, Calculator, FlaskConical, Leaf, Heart, Download, Video } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

const subjects = [
  {
    id: "language",
    label: "Language",
    icon: BookOpen,
    activities: [
      {
        title: "Story Circle",
        description: "Students sit in a circle and create a collaborative story, each adding one sentence",
        materials: "None needed",
        skills: "Speaking, listening, creativity, sequencing",
      },
      {
        title: "Picture Reading",
        description: "Use picture cards to build vocabulary and create sentences",
        materials: "Picture cards, local images",
        skills: "Vocabulary, sentence formation, observation",
      },
      {
        title: "Role-Play Conversations",
        description: "Act out everyday scenarios like shopping, visiting doctor, helping at home",
        materials: "Simple props",
        skills: "Speaking, confidence, practical language use",
      },
      {
        title: "Sound Hunt",
        description: "Find objects that start with specific sounds or letters",
        materials: "Objects from classroom/nature",
        skills: "Phonics, letter recognition, vocabulary",
      },
      {
        title: "Story Sequencing",
        description: "Arrange picture cards to tell a story in correct order",
        materials: "Story sequence cards",
        skills: "Comprehension, logical thinking, narrative structure",
      },
    ],
  },
  {
    id: "math",
    label: "Math",
    icon: Calculator,
    activities: [
      {
        title: "Number Line Jump",
        description: "Physical number line on ground, students jump to solve addition/subtraction",
        materials: "Chalk or rope",
        skills: "Number sense, operations, physical coordination",
      },
      {
        title: "Pattern Making",
        description: "Create and extend patterns using stones, leaves, or colored objects",
        materials: "Natural objects, colored items",
        skills: "Pattern recognition, logical thinking, creativity",
      },
      {
        title: "Measurement Hunt",
        description: "Measure classroom objects using hands, feet, or string",
        materials: "String, ruler (optional)",
        skills: "Measurement, comparison, estimation",
      },
      {
        title: "Fraction Pizza",
        description: "Use circular objects or drawings to understand fractions",
        materials: "Paper circles, real food items",
        skills: "Fractions, division, visual representation",
      },
      {
        title: "Shop Simulation",
        description: "Set up a pretend shop to practice money, addition, and subtraction",
        materials: "Play money, items with prices",
        skills: "Money concepts, operations, real-world application",
      },
    ],
  },
  {
    id: "science",
    label: "Science",
    icon: FlaskConical,
    activities: [
      {
        title: "Seed Germination",
        description: "Plant seeds and observe daily growth, documenting changes",
        materials: "Seeds, soil, water, containers",
        skills: "Observation, recording, plant life cycle, patience",
      },
      {
        title: "Shadow Tracking",
        description: "Mark shadow positions at different times to understand sun movement",
        materials: "Chalk, stick",
        skills: "Observation, time, earth's rotation, measurement",
      },
      {
        title: "Water Experiments",
        description: "Explore floating/sinking, dissolving, water cycle demonstrations",
        materials: "Water, various objects, containers",
        skills: "Scientific method, properties of matter, prediction",
      },
      {
        title: "Magnet Exploration",
        description: "Test which objects are attracted to magnets",
        materials: "Magnet, various objects",
        skills: "Classification, properties of materials, testing",
      },
      {
        title: "Weather Journal",
        description: "Daily observation and recording of weather conditions",
        materials: "Notebook, observation tools",
        skills: "Observation, recording, patterns, data collection",
      },
    ],
  },
  {
    id: "evs",
    label: "EVS",
    icon: Leaf,
    activities: [
      {
        title: "Nature Walk",
        description: "Explore local environment, collect and classify natural objects",
        materials: "Collection bags, magnifying glass",
        skills: "Observation, classification, environmental awareness",
      },
      {
        title: "Community Mapping",
        description: "Create a map of the village showing important places",
        materials: "Large paper, drawing materials",
        skills: "Spatial awareness, community knowledge, mapping",
      },
      {
        title: "Water Source Study",
        description: "Visit and study local water sources, discuss conservation",
        materials: "Notebook, camera (optional)",
        skills: "Environmental awareness, conservation, observation",
      },
      {
        title: "Traditional Knowledge",
        description: "Interview elders about traditional practices and local history",
        materials: "Notebook for recording",
        skills: "Communication, cultural awareness, respect for elders",
      },
      {
        title: "Waste Sorting",
        description: "Collect and sort waste into categories, discuss recycling",
        materials: "Collected waste, sorting bins",
        skills: "Classification, environmental responsibility, problem-solving",
      },
    ],
  },
  {
    id: "life-skills",
    label: "Life Skills",
    icon: Heart,
    activities: [
      {
        title: "Problem-Solving Scenarios",
        description: "Present real-life problems and discuss solutions in groups",
        materials: "Scenario cards",
        skills: "Critical thinking, decision-making, collaboration",
      },
      {
        title: "Emotion Charades",
        description: "Act out different emotions, others guess and discuss",
        materials: "Emotion cards",
        skills: "Emotional intelligence, empathy, expression",
      },
      {
        title: "Hygiene Demonstration",
        description: "Practice and teach proper handwashing, tooth brushing",
        materials: "Water, soap, demonstration materials",
        skills: "Health awareness, personal hygiene, teaching others",
      },
      {
        title: "Conflict Resolution Role-Play",
        description: "Act out conflicts and practice peaceful resolution strategies",
        materials: "Scenario cards",
        skills: "Communication, empathy, problem-solving, peace-building",
      },
      {
        title: "Goal Setting",
        description: "Students set personal learning goals and track progress",
        materials: "Goal sheets, progress charts",
        skills: "Self-awareness, planning, motivation, reflection",
      },
    ],
  },
]

export function SubjectActivities() {
  const { toast } = useToast()

  const handleDownloadActivity = (activityTitle: string) => {
    toast({
      title: "Download Started",
      description: `Downloading detailed guide for "${activityTitle}"...`,
    })
  }

  const handleWatchDemo = (activityTitle: string) => {
    toast({
      title: "Video Demo",
      description: `Opening video demonstration for "${activityTitle}"...`,
    })
  }

  return (
    <section id="subject-activities" className="py-16 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4 text-balance">
            Activities for Each Subject
          </h2>
          <p className="text-lg text-muted-foreground text-balance">
            Practical, engaging activities that bring each subject to life using minimal resources.
          </p>
        </div>
        <Tabs defaultValue="language" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 h-auto gap-2 bg-transparent">
            {subjects.map((subject) => (
              <TabsTrigger
                key={subject.id}
                value={subject.id}
                className="flex flex-col items-center gap-1 py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                <subject.icon className="h-5 w-5" />
                <span className="text-sm">{subject.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>
          {subjects.map((subject) => (
            <TabsContent key={subject.id} value={subject.id} className="mt-6">
              <div className="grid gap-4 md:grid-cols-2">
                {subject.activities.map((activity, index) => (
                  <Card key={index} className="border-2">
                    <CardHeader>
                      <CardTitle className="text-lg">{activity.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-sm leading-relaxed">{activity.description}</p>
                      <div className="space-y-2 text-sm">
                        <div>
                          <span className="font-semibold text-primary">Materials: </span>
                          <span className="text-muted-foreground">{activity.materials}</span>
                        </div>
                        <div>
                          <span className="font-semibold text-primary">Skills: </span>
                          <span className="text-muted-foreground">{activity.skills}</span>
                        </div>
                      </div>
                      <div className="flex gap-2 pt-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              className="flex-1 bg-transparent"
                              onClick={() => handleWatchDemo(activity.title)}
                            >
                              <Video className="h-4 w-4 mr-1" />
                              Demo
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle>{activity.title} - Video Demo</DialogTitle>
                              <DialogDescription>
                                Step-by-step demonstration of how to conduct this activity
                              </DialogDescription>
                            </DialogHeader>
                            <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                              <div className="text-center">
                                <Video className="h-16 w-16 mx-auto mb-4 text-primary" />
                                <p className="text-muted-foreground">Video demonstration coming soon</p>
                              </div>
                            </div>
                            <div className="space-y-2 mt-4">
                              <h4 className="font-semibold text-sm">Step-by-Step Instructions:</h4>
                              <ol className="space-y-2 text-sm text-muted-foreground ml-4">
                                <li>1. Prepare materials and set up the activity space</li>
                                <li>2. Introduce the activity and explain objectives to students</li>
                                <li>3. Demonstrate or model the activity</li>
                                <li>4. Guide students through the activity</li>
                                <li>5. Facilitate reflection and discussion</li>
                              </ol>
                            </div>
                          </DialogContent>
                        </Dialog>
                        <Button size="sm" className="flex-1" onClick={() => handleDownloadActivity(activity.title)}>
                          <Download className="h-4 w-4 mr-1" />
                          Guide
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  )
}
