"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles } from "lucide-react"

export function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" })
    }
  }

  return (
    <section className="relative overflow-hidden border-b">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5" />

      <div className="container relative px-4 md:px-6 py-24 md:py-32">
        <div className="mx-auto max-w-4xl text-center space-y-8">
          <div className="inline-flex items-center gap-2 rounded-full border bg-card px-4 py-2 text-sm">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-balance">Reimagining Education for Rural Communities</span>
          </div>

          <h1 className="font-poppins font-bold text-4xl md:text-6xl lg:text-7xl text-balance leading-tight">
            Every Child Deserves Quality Education
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto text-pretty leading-relaxed">
            {
              "How might we create models of alternative education for developing meaningful teaching-learning systems for children studying in rural schools that often lack basic infrastructural facilities?"
            }
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button size="lg" className="gap-2" onClick={() => scrollToSection("solutions")}>
              Explore Our Vision
              <ArrowRight className="h-5 w-5" />
            </Button>
            <Button size="lg" variant="outline" onClick={() => scrollToSection("impact")}>
              Join the Movement
            </Button>
          </div>
        </div>
      </div>

      <div className="container px-4 md:px-6 pb-16">
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <div className="bg-card border rounded-xl p-6 text-center">
            <div className="text-4xl font-bold text-primary mb-2">260M+</div>
            <p className="text-sm text-muted-foreground">Children out of school globally</p>
          </div>
          <div className="bg-card border rounded-xl p-6 text-center">
            <div className="text-4xl font-bold text-secondary mb-2">70%</div>
            <p className="text-sm text-muted-foreground">Rural schools lack basic facilities</p>
          </div>
          <div className="bg-card border rounded-xl p-6 text-center">
            <div className="text-4xl font-bold text-accent mb-2">50%+</div>
            <p className="text-sm text-muted-foreground">Learning poverty in low-income areas</p>
          </div>
        </div>
      </div>
    </section>
  )
}
