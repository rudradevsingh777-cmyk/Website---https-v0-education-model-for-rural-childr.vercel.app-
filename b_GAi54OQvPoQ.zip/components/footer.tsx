"use client"

import { BookOpen } from "lucide-react"
import Link from "next/link"

export function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      window.scrollTo({ top: 0, behavior: "smooth" })
      setTimeout(() => {
        const targetElement = document.getElementById(sectionId)
        if (targetElement) {
          targetElement.scrollIntoView({ behavior: "smooth", block: "start" })
        }
      }, 100)
    }
  }

  return (
    <footer className="border-t bg-muted/30">
      <div className="container px-4 md:px-6 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                <BookOpen className="h-6 w-6 text-primary-foreground" />
              </div>
              <div className="flex flex-col">
                <span className="font-poppins font-bold text-lg leading-none">EduReach</span>
                <span className="text-xs text-muted-foreground">Alternative Education</span>
              </div>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Creating meaningful education opportunities for every child, regardless of their circumstances.
            </p>
          </div>

          <div>
            <h3 className="font-poppins font-semibold mb-4">Learn More</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/about" className="hover:text-primary transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <button onClick={() => scrollToSection("problem")} className="hover:text-primary transition-colors">
                  Our Research
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("solutions")} className="hover:text-primary transition-colors">
                  Case Studies
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("impact")} className="hover:text-primary transition-colors">
                  Resources
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-poppins font-semibold mb-4">Get Involved</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/contact?type=partner" className="hover:text-primary transition-colors">
                  Partner With Us
                </Link>
              </li>
              <li>
                <Link href="/contact?type=volunteer" className="hover:text-primary transition-colors">
                  Volunteer
                </Link>
              </li>
              <li>
                <Link href="/contact?type=donate" className="hover:text-primary transition-colors">
                  Donate
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-primary transition-colors">
                  Careers
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-poppins font-semibold mb-4">Connect</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/contact" className="hover:text-primary transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <button onClick={() => scrollToSection("impact")} className="hover:text-primary transition-colors">
                  Newsletter
                </button>
              </li>
              <li>
                <Link href="/contact" className="hover:text-primary transition-colors">
                  Social Media
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-primary transition-colors">
                  Blog
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <p>© 2025 EduReach Alternative Education Initiative. All rights reserved.</p>
          <div className="flex gap-6">
            <Link href="/privacy" className="hover:text-primary transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms" className="hover:text-primary transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
