import { Card } from "@/components/ui/card"

export function Impact() {
  return (
    <section id="impact" className="py-24 md:py-32 border-b">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-16">
          <h2 className="font-poppins font-bold text-3xl md:text-5xl mb-6 text-balance">Expected Impact & Outcomes</h2>
          <p className="text-lg text-muted-foreground text-pretty leading-relaxed">
            By implementing alternative education models, we envision transforming rural education landscapes and
            creating lasting change for generations.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Card className="p-8 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
            <h3 className="font-poppins font-semibold text-xl mb-4">For Students</h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Enhanced engagement and joy in learning</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Development of critical thinking and creativity</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Improved learning outcomes and retention</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Stronger connection to culture and identity</span>
              </li>
            </ul>
          </Card>

          <Card className="p-8 bg-gradient-to-br from-secondary/5 to-secondary/10 border-secondary/20">
            <h3 className="font-poppins font-semibold text-xl mb-4">For Teachers</h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-secondary mt-1">•</span>
                <span>Professional growth and skill development</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-secondary mt-1">•</span>
                <span>Access to peer support networks</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-secondary mt-1">•</span>
                <span>Empowerment to innovate in classrooms</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-secondary mt-1">•</span>
                <span>Recognition and renewed motivation</span>
              </li>
            </ul>
          </Card>

          <Card className="p-8 bg-gradient-to-br from-accent/5 to-accent/10 border-accent/20">
            <h3 className="font-poppins font-semibold text-xl mb-4">For Communities</h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent mt-1">•</span>
                <span>Increased parental and community engagement</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent mt-1">•</span>
                <span>Preservation and integration of local knowledge</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent mt-1">•</span>
                <span>Economic empowerment through education</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent mt-1">•</span>
                <span>Strengthened social cohesion</span>
              </li>
            </ul>
          </Card>

          <Card className="p-8 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5 border-primary/20">
            <h3 className="font-poppins font-semibold text-xl mb-4">For Society</h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Reduced educational inequality</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Sustainable development in rural areas</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Scalable models for educational reform</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Building equitable futures</span>
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </section>
  )
}
