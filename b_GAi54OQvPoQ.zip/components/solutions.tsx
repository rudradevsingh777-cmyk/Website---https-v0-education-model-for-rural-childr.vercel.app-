import { Card } from "@/components/ui/card"
import { Lightbulb, Heart, Users2, Sprout, BookOpen, Compass } from "lucide-react"

export function Solutions() {
  const solutions = [
    {
      icon: Lightbulb,
      color: "text-primary",
      bgColor: "bg-primary/10",
      title: "Community-Based Learning Centers",
      description:
        "Establish flexible learning spaces within villages using local resources, community halls, and outdoor environments as classrooms.",
    },
    {
      icon: Users2,
      color: "text-secondary",
      bgColor: "bg-secondary/10",
      title: "Teacher Empowerment Programs",
      description:
        "Provide continuous training, peer learning networks, and support systems for teachers to adopt innovative, child-centered teaching methods.",
    },
    {
      icon: BookOpen,
      color: "text-accent",
      bgColor: "bg-accent/10",
      title: "Localized Curriculum Design",
      description:
        "Develop culturally relevant, multilingual learning materials that connect education to students' lived experiences and local knowledge systems.",
    },
    {
      icon: Sprout,
      color: "text-primary",
      bgColor: "bg-primary/10",
      title: "Activity-Based Learning",
      description:
        "Implement experiential learning through hands-on projects, arts, sports, and practical activities that make education engaging and meaningful.",
    },
    {
      icon: Heart,
      color: "text-secondary",
      bgColor: "bg-secondary/10",
      title: "Holistic Development Focus",
      description:
        "Go beyond academics to nurture emotional intelligence, life skills, creativity, and values that prepare children for life, not just exams.",
    },
    {
      icon: Compass,
      color: "text-accent",
      bgColor: "bg-accent/10",
      title: "Technology Integration",
      description:
        "Leverage low-cost, accessible technology solutions including offline content, mobile learning, and community digital hubs where feasible.",
    },
  ]

  return (
    <section id="solutions" className="py-24 md:py-32 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-16">
          <h2 className="font-poppins font-bold text-3xl md:text-5xl mb-6 text-balance">
            Our Alternative Education Model
          </h2>
          <p className="text-lg text-muted-foreground text-pretty leading-relaxed">
            A comprehensive approach that reimagines education to be accessible, contextual, joyful, and transformative
            for rural children despite infrastructure limitations.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {solutions.map((solution, index) => {
            const Icon = solution.icon
            return (
              <Card key={index} className="p-6 hover:shadow-lg transition-all hover:-translate-y-1">
                <div className={`w-12 h-12 rounded-lg ${solution.bgColor} flex items-center justify-center mb-4`}>
                  <Icon className={`h-6 w-6 ${solution.color}`} />
                </div>
                <h3 className="font-poppins font-semibold text-lg mb-3 text-balance">{solution.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{solution.description}</p>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
