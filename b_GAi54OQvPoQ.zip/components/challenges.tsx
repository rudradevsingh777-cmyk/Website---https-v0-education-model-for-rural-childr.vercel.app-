import { Badge } from "@/components/ui/badge"

export function Challenges() {
  const challenges = [
    "Limited funding and resources",
    "Poor connectivity and digital divide",
    "Socio-economic barriers",
    "Migration and seasonal education disruption",
    "Multi-grade teaching complexities",
    "Language barriers",
    "Parental awareness and engagement",
    "Geographic isolation",
    "Gender inequality in education access",
  ]

  return (
    <section id="challenges" className="py-24 md:py-32 border-b">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-12">
          <h2 className="font-poppins font-bold text-3xl md:text-5xl mb-6 text-balance">
            Key Challenges We Must Address
          </h2>
          <p className="text-lg text-muted-foreground text-pretty leading-relaxed">
            Understanding the complexity of rural education requires acknowledging the interconnected challenges that
            students, teachers, and communities face daily.
          </p>
        </div>

        <div className="flex flex-wrap gap-3 justify-center max-w-4xl mx-auto">
          {challenges.map((challenge, index) => (
            <Badge
              key={index}
              variant="outline"
              className="px-4 py-2 text-sm hover:bg-primary hover:text-primary-foreground hover:border-primary transition-colors cursor-default"
            >
              {challenge}
            </Badge>
          ))}
        </div>
      </div>
    </section>
  )
}
