import { Card } from "@/components/ui/card"
import { AlertCircle, Users, Building, GraduationCap } from "lucide-react"

export function ProblemStatement() {
  return (
    <section id="problem" className="py-24 md:py-32 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center mb-16">
          <h2 className="font-poppins font-bold text-3xl md:text-5xl mb-6 text-balance">
            The Education Crisis in Rural Areas
          </h2>
          <p className="text-lg text-muted-foreground text-pretty leading-relaxed">
            Millions of children in rural communities face barriers to quality education that go far beyond access. The
            challenge is systemic, multifaceted, and urgent.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <Card className="p-8 hover:shadow-lg transition-shadow">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Building className="h-6 w-6 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="font-poppins font-semibold text-xl">Infrastructure Gap</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Rural schools often lack basic infrastructure including proper classrooms, electricity, clean water,
                  functional toilets, and adequate learning materials.
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-8 hover:shadow-lg transition-shadow">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center">
                <Users className="h-6 w-6 text-secondary" />
              </div>
              <div className="space-y-2">
                <h3 className="font-poppins font-semibold text-xl">Teacher Shortage</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Limited qualified teachers, high student-teacher ratios, and lack of continuous professional
                  development hinder effective teaching in rural contexts.
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-8 hover:shadow-lg transition-shadow">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                <GraduationCap className="h-6 w-6 text-accent" />
              </div>
              <div className="space-y-2">
                <h3 className="font-poppins font-semibold text-xl">Outdated Pedagogy</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Traditional rote learning methods fail to engage students or develop critical thinking, creativity,
                  and practical skills needed for the modern world.
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-8 hover:shadow-lg transition-shadow">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center">
                <AlertCircle className="h-6 w-6 text-destructive" />
              </div>
              <div className="space-y-2">
                <h3 className="font-poppins font-semibold text-xl">Contextual Disconnect</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Curriculum and teaching methods often ignore local culture, language, and real-life contexts that make
                  learning relevant and meaningful for rural children.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
