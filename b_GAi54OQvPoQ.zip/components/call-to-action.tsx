"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowRight, Mail } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"

export function CallToAction() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !email.includes("@")) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    toast({
      title: "Success!",
      description: "You've been subscribed to our updates.",
    })

    setEmail("")
    setIsLoading(false)
  }

  return (
    <section className="py-24 md:py-32 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl">
          <Card className="p-8 md:p-12 text-center shadow-lg">
            <h2 className="font-poppins font-bold text-3xl md:text-4xl mb-4 text-balance">
              Join Us in Transforming Rural Education
            </h2>
            <p className="text-lg text-muted-foreground mb-8 text-pretty leading-relaxed">
              Whether you're an educator, researcher, NGO, policymaker, or concerned citizen, there's a role for you in
              creating meaningful change. Together, we can build education systems that truly serve every child.
            </p>

            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto mb-8">
              <div className="flex-1 relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="pl-10"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              <Button type="submit" size="lg" className="gap-2" disabled={isLoading}>
                {isLoading ? "Subscribing..." : "Get Updates"}
                <ArrowRight className="h-5 w-5" />
              </Button>
            </form>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="outline" size="lg" onClick={() => router.push("/contact?type=partner")}>
                Partner With Us
              </Button>
              <Button variant="outline" size="lg" onClick={() => router.push("/contact?type=volunteer")}>
                Volunteer
              </Button>
              <Button variant="outline" size="lg" onClick={() => router.push("/contact?type=donate")}>
                Donate
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
